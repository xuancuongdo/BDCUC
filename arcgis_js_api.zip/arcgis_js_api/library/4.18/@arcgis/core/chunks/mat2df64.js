/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(){return[1,0,0,1,0,0]}function r(n){return[n[0],n[1],n[2],n[3],n[4],n[5]]}export{r as a,n as c};
