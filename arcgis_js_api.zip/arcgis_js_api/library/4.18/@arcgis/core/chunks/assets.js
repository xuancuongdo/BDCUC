/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import r from"../config.js";import{join as t}from"../core/urlUtils.js";import o from"../request.js";function s(r,t){return o(e(r),t)}function e(o){return t(r.assetsPath,o)}export{s as f,e as g};
