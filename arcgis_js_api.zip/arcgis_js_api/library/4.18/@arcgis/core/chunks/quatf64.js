/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(){return[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}function r(n){return[n[0],n[1],n[2],n[3],n[4],n[5],n[6],n[7],n[8],n[9],n[10],n[11],n[12],n[13],n[14],n[15]]}function t(n,r,t,a,u,o,e,s,c,f,i,l,w,y,A,F){return[n,r,t,a,u,o,e,s,c,f,i,l,w,y,A,F]}function a(n,r){return new Float64Array(n,r,16)}const u=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];function o(){return[1,0,0,0,1,0,0,0,1]}function e(n,r){return new Float64Array(n,r,9)}function s(){return[0,0,0,1]}function c(n){return[n[0],n[1],n[2],n[3]]}function f(n,r){return new Float64Array(n,r,4)}const i=[0,0,0,1];export{u as I,o as a,s as b,n as c,r as d,e,t as f,a as g,f as h,i,c as j};
