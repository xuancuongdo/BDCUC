/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(n,r){for(const[f,o]of n)if(r(o,f))return!0;return!1}function r(n,r){for(const[f,o]of n)if(r(o,f))return o;return null}export{r as f,n as s};
