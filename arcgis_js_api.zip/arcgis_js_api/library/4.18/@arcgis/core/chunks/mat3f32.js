/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(){const n=new Float32Array(9);return n[0]=1,n[4]=1,n[8]=1,n}function r(n){const r=new Float32Array(9);return r[0]=n[0],r[1]=n[1],r[2]=n[2],r[3]=n[3],r[4]=n[4],r[5]=n[5],r[6]=n[6],r[7]=n[7],r[8]=n[8],r}function t(n,r,t,a,o,c,e,s,u){const f=new Float32Array(9);return f[0]=n,f[1]=r,f[2]=t,f[3]=a,f[4]=o,f[5]=c,f[6]=e,f[7]=s,f[8]=u,f}export{r as a,n as c,t as f};
