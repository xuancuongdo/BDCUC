/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import s from"../symbols/Symbol.js";import e from"../symbols/PolygonSymbol3D.js";import{s as t,write as o,a as p,b as r}from"../symbols/support/jsonUtils.js";const i={types:p,json:{write:{writer:o},origins:{"web-scene":{types:r,write:{writer:o}}}}},l={types:{base:s,key:"type",typeMap:{"simple-fill":t.typeMap["simple-fill"],"picture-fill":t.typeMap["picture-fill"],"polygon-3d":t.typeMap["polygon-3d"]}},json:{write:{writer:o},origins:{"web-scene":{type:e,write:{writer:o}}}}};export{i as a,l as r};
