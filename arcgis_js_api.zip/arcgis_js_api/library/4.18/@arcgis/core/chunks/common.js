/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
const t=1e-6,a=Math.random,n=Math.PI/180,r=180/Math.PI;function o(t){return t*n}function s(t){return t*r}export{t as E,a as R,s as a,o as t};
