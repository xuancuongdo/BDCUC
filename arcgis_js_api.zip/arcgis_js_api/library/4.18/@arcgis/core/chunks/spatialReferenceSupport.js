/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function i(i,r){return null!=i&&("2d"===r||("local"===r?!i.isGeographic:i.isWebMercator||i.isWGS84||4490===i.wkid||104971===i.wkid||104905===i.wkid||104903===i.wkid))}export{i};
