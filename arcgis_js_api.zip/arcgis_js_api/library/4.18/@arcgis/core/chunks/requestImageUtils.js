/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import e from"../request.js";async function r(r,t){const{data:a}=await e(r,{responseType:"image",...t});return a}export{r};
