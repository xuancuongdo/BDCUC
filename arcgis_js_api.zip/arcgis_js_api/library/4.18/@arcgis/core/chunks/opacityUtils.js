/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import{m as t}from"./ensureType.js";function n(n){const a=t(100*(1-n));return Math.max(0,Math.min(a,100))}function a(t){const n=1-t/100;return Math.max(0,Math.min(n,1))}export{n as o,a as t};
