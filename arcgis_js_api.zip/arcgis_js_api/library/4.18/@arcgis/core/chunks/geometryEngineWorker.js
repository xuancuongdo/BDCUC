/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import"./_commonjsHelpers.js";import"./geometryEngineBase.js";import"./json.js";import{g as e}from"./geometryEngineJSON.js";function o(o){return(0,e[o.operation])(...o.parameters)}export{o as executeGEOperation};
