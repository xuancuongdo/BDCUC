/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(n){return[255&n,(65280&n)>>>8,(16711680&n)>>>16,(4278190080&n)>>>24]}function r(n,r){return 65535&n|r<<16}function t(n,r,t,u){return 255&n|(255&r)<<8|(255&t)<<16|u<<24}export{t as a,r as i,n as u};
