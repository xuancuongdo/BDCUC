/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
import r from"../core/Collection.js";function n(n,e,t=r){return e||(e=new t),e===n||(e.removeAll(),!function(r){return r&&(Array.isArray(r)||"items"in r&&Array.isArray(r.items))}(n)?n&&e.add(n):e.addMany(n)),e}function e(r){return r}export{e as c,n as r};
