/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function e(e,t){if(!s(e,t)){const s=e.typeKeywords;s?s.push(t):e.typeKeywords=[t]}}function s(e,s){return!!e.typeKeywords&&e.typeKeywords.indexOf(s)>-1}function t(e,s){const t=e.typeKeywords;if(t){const e=t.indexOf(s);e>-1&&t.splice(e,1)}}export{e as a,s as h,t as r};
