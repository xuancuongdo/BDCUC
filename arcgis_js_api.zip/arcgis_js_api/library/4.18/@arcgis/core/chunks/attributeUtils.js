/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(n,r,t){if(!t||null==r)return null;if(!n)return function(n,r){const t=r.toLowerCase();for(const r in n)if(r.toLowerCase()===t)return n[r];return null}(r,t);const e=n.get(t);return e?r[e.name]:null}export{n as a};
