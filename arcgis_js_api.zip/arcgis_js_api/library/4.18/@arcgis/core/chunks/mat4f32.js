/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.18/esri/copyright.txt for details.
*/
function n(){const n=new Float32Array(16);return n[0]=1,n[5]=1,n[10]=1,n[15]=1,n}n();export{n as c};
